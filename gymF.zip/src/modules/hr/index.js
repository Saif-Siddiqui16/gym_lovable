export { default as StaffList } from './pages/StaffList';
export { default as StaffForm } from './pages/StaffForm';
export { default as Payroll } from './pages/Payroll';
export { default as TrainerAssignment } from './pages/TrainerAssignment';
