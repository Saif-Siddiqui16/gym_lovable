const BaseUrl = "http://localhost:8000/api/v1";
//const BaseUrl = "https://gym-saif-production.up.railway.app/api/v1"
export default BaseUrl;