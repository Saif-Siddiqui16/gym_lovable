export { default as ClassesList } from './pages/ClassesList';
export { default as ClassDetails } from './pages/ClassDetails';
export { default as ClassForm } from './pages/ClassForm';
export { default as TrainerAssignment } from './pages/TrainerAssignment';
export { default as MemberEnrollment } from './pages/MemberEnrollment';
