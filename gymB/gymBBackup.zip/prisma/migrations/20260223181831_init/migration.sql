-- AlterTable
ALTER TABLE `member` ADD COLUMN `targetBodyFat` DECIMAL(5, 2) NULL,
    ADD COLUMN `targetWeight` DECIMAL(5, 2) NULL;
